#ifndef _COLORCONTROL_H
#define _COLORCONTROL_H

#define WM_GETCOLOR WM_USER+500
#define WM_SETCOLOR WM_USER+501

ATOM RegisterColorControl();

#endif