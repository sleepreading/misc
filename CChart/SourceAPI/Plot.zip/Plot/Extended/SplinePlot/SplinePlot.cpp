/*============================================================================*/
/*                                                                            */
/*                            C O P Y R I G H T                               */
/*                                                                            */
/*                          (C) Copyright 2011 by                             */
/*                              Yang Guojun                                   */
/*                           All Rights Reserved                              */
/*                                                                            */
/*      The author assumes no responsibility for the use or reliability of    */
/*      his software.                                                         */
/*                                                                            */
/*============================================================================*/

/* ############################################################################################################################## */

#include "stdafx.h"
#include "SplinePlot.h"

CSplinePlot::CSplinePlot()
{
	SetDefaults();
}

CSplinePlot::~CSplinePlot()
{
}

void	CSplinePlot::SetDefaults()
{
}

void	CSplinePlot::CopySettings(CSplinePlot *plot)
{

}
